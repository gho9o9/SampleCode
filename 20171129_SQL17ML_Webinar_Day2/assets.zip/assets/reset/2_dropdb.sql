EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N'sql17mlhandson'
GO
USE [master]
GO
DROP DATABASE [sql17mlhandson]
GO
