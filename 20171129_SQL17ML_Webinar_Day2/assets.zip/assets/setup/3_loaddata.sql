BULK INSERT HumanCharacteristics
FROM 'c:\3_dataset.csv'
WITH
(
   FIELDTERMINATOR = ','
);